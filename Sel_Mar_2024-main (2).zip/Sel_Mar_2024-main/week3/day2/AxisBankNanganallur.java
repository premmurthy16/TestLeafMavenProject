package week3.day2;

public abstract class AxisBankNanganallur implements RBI{
	
	@Override
	public void knowYourCustomer() {
		// TODO Auto-generated method stub
		
	}
	
	public void homeLoan() {
       System.out.println("7.5% interest rate");		

	}
	
	public abstract void digitalTransaction();
	
	
	

}
