package week1.day1;

public class FirstProgram {

	// main method is the entry point for execution
	// type main -> do ctrl+space -> Click Enter
	public static void main(String[] args) {

		//print a statement
		//  type syso -> ctrl+space -> Click Enter
		// ctrl+f11 -> shortcut key to run the program
		System.out.println("Hey All!! Welcome to TestLeaf Learning");

	}

}
