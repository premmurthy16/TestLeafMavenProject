package week1.day2;

public class LearnAccessModifier {
public static void main(String[] args) {
	LearnMethods lm = new LearnMethods();
	
	lm.bicycleData("Maruthi", "Black");
	
}
}
