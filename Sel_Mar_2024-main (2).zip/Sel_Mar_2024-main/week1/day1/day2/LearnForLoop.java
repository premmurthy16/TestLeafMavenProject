package week1.day2;

public class LearnForLoop {

	public static void main(String[] args) {
		// print numbers from 1 to 10
		// type for  -> ctrl+space -> click 2nd for loop -> click Enter
		int num=10;
		// Print even numbers from 1 to 10

		for (int i = 1; i <=num; i++) { // i=4; 4<=10;
			if(i%2==0) {  // 4%2 == 2 -> t
				System.out.println(i); // 2 4 
			}

		}

	}

}
