package week1.day2;

public class LearnSwitchCase {
	public static void main(String[] args) {
		String browser = "Chrome";
		
		switch (browser) {
		case "Chrome": System.out.println("Chrome browser launched Successfully");break;
		case "Safari": System.out.println("Safari browser launched Successfully");break;
		case "Firefox": System.out.println("Firefox browser launched Successfully");break;
		case "IE": System.out.println("IE browser launched Successfully");break;
		default: System.out.println("Edge browser launched Successfully");break;		
		}
		
		
	}

}
